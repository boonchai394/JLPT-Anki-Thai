# JLPT Kanji Anki Generator - Thai Edition

## ใช้ยังไง
1. แตก zip
2. เปิด Terminal / Command Prompt ในโฟลเดอร์นี้
3. รัน:
   python build_decks.py

## ถ้าอยากได้ไฟล์ .apkg
ติดตั้งก่อน:
   pip install genanki

แล้วรัน:
   python build_decks.py

## ถ้าไม่ติดตั้ง genanki
ยังได้ไฟล์ CSV ในโฟลเดอร์ export_csv ใช้นำเข้า Anki ได้

## วิธีเพิ่มคันจิ
เปิดไฟล์ build_decks.py แล้วเพิ่มข้อมูลใน DATA ตามตัวอย่างเดิม
